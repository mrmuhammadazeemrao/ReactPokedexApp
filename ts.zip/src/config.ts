export const config = {
  URL: {
    BASE_URL: "https://pokeapi.co/api/v2/pokemon/" as string,
  },
};
