import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { config } from "../config";

export const pokemonApi = createApi({
  reducerPath: "pokemonApi",
  baseQuery: fetchBaseQuery({ baseUrl: config.URL.BASE_URL }),
  endpoints: (builder) => ({
    fetchPokemon: builder.query<any, string>({
      query: (url) => url,
    }),
  }),
});

export const { useFetchPokemonQuery } = pokemonApi;
