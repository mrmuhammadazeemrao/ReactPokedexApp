import React from "react";
import { render, screen } from "@testing-library/react";
import { useSelector } from "react-redux";
import PokemonPage from "../pages/PokemonPage";

jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => jest.fn(),
}));

describe("Pokemon Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should display "Loading" text when the loading state is true', () => {
    (useSelector as any).mockReturnValue({
      pokemons: null,
      loading: true,
      error: null,
    });

    render(<PokemonPage />);
    expect(screen.getByText("Loading"));
  });

  it("should display error message when there is an error", () => {
    (useSelector as any).mockReturnValue({
      pokemons: null,
      loading: false,
      error: "Error",
    });

    render(<PokemonPage />);
    expect(screen.getByText("Something went wrong"));
  });
});
