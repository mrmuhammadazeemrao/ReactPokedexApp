import React from "react";
import { render, screen } from "@testing-library/react";
import { useSelector } from "react-redux";
import HomePage from "../pages/HomePage";

jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => jest.fn(),
}));

describe("HomePage Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should display "Loading" text when the loading state is true', () => {
    (useSelector as any).mockReturnValue({
      pokemons: null,
      loading: true,
      error: null,
    });

    render(<HomePage />);
    expect(screen.getByText("Loading"));
  });

  it("should display error message when there is an error", () => {
    (useSelector as any).mockReturnValue({
      pokemons: null,
      loading: false,
      error: "Error",
    });

    render(<HomePage />);
    expect(screen.getByText("Something went wrong"));
  });
});
