import React, { useState, useEffect } from "react";
import { config } from "../config";
import TableData from "../components/TableData";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { fetchPokemons } from "../reducers/pokemonReducer";

const HomePage: React.FC = () => {
  const [limit, setLimit] = useState<number>(20);
  const [page, setPage] = useState(0);
  const [url, setUrl] = useState<string>(
    `${config.URL.BASE_URL}?offset=1&limit=${limit}`
  );
  const dispatch = useDispatch();
  const { pokemons, loading, error } = useSelector(
    (state: any) => state.pokemon
  );

  useEffect(() => {
    // @ts-ignore
    dispatch(fetchPokemons(url));
  }, [dispatch, url]);

  useEffect(() => {
    setUrl(`${config.URL.BASE_URL}?offset=1&limit=${limit}`);
  }, [limit]);

  const paginatedData = (previousUrl: string) => {
    setUrl(previousUrl);
  };

  if (loading) return <div>Loading</div>;
  if (error) return <div>Something went wrong</div>;

  return (
    <div>
      {!!pokemons && !!pokemons.results && (
        <TableData
          pokemons={pokemons}
          paginatedData={paginatedData}
          limit={limit}
          setLimit={setLimit}
          page={page}
          setPage={setPage}
        />
      )}
    </div>
  );
};

export default HomePage;
